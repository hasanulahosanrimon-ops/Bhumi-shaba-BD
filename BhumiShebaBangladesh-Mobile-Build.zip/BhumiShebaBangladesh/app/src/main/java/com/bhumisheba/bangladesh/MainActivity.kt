package com.bhumisheba.bangladesh

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import android.graphics.drawable.GradientDrawable

data class ServiceLink(val title: String, val category: String, val url: String, val note: String)

class MainActivity : Activity() {
    private val green = Color.rgb(23, 107, 69)
    private val links = listOf(
        ServiceLink("আমার ভূমি", "ভূমি সেবা", "https://www.amarvumi.com/", "বেসরকারি ওয়েবসাইট"),
        ServiceLink("ই-পর্চা সার্ভে খতিয়ান", "খতিয়ান", "https://eporcha.top/services/survey-khatiyan", "বেসরকারি ওয়েবসাইট"),
        ServiceLink("ই-পর্চা টেক", "খতিয়ান", "https://www.eporcha.tech/", "বেসরকারি ওয়েবসাইট"),
        ServiceLink("ই-পর্চা মৌজা ম্যাপ", "মৌজা ম্যাপ", "https://e-porcha.com/mouza-map", "বেসরকারি ওয়েবসাইট"),
        ServiceLink("NDS ডিজিটাল সার্ভে", "মৌজা ম্যাপ", "https://www.ndsdigitalsurvey.com/mouza-map/", "বেসরকারি ওয়েবসাইট"),
        ServiceLink("নাগরিক সেবা হাব", "নাগরিক সেবা", "https://nagoriksebahub.com/dashboard", "বেসরকারি ওয়েবসাইট"),
        ServiceLink("ভূমি সেবা", "ভূমি সেবা", "https://app.bhumisheba.com/", "বেসরকারি ওয়েবসাইট")
    )

    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var search: EditText
    private var webView: WebView? = null
    private var currentTitle = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 18): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun base(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(247, 249, 247))
        }
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun showHome(query: String = "") {
        webView = null
        root = base()
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
            setBackgroundColor(green)
        }
        header.addView(text("ভূমি সেবা বাংলাদেশ", 24f, Color.WHITE, true))
        header.addView(text("সকল ভূমি সেবা এক জায়গায়", 14f, Color.rgb(225, 243, 232)).apply {
            setPadding(0, dp(5), 0, dp(14))
        })
        search = EditText(this).apply {
            hint = "সেবা খুঁজুন..."
            textSize = 15f
            singleLine = true
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = rounded(Color.WHITE, 14)
            setText(query)
        }
        header.addView(search)
        root.addView(header)

        val disclaimer = text("নোট: এখানে যুক্ত লিংকগুলো তৃতীয় পক্ষের ওয়েবসাইট। সরকারি সেবা ব্যবহারের আগে সাইটের পরিচয় যাচাই করুন।", 12f, Color.DKGRAY)
        disclaimer.setPadding(dp(16), dp(12), dp(16), dp(8))
        root.addView(disclaimer)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(4), dp(14), dp(24))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        renderCards(query)
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderCards(s?.toString() ?: "") }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        setContentView(root)
    }

    private fun renderCards(query: String) {
        content.removeAllViews()
        val filtered = links.filter {
            it.title.contains(query, true) || it.category.contains(query, true) || it.url.contains(query, true)
        }
        val categories = filtered.groupBy { it.category }
        if (filtered.isEmpty()) {
            content.addView(text("কোনো সেবা পাওয়া যায়নি।", 15f, Color.DKGRAY).apply { setPadding(dp(8), dp(18), dp(8), dp(18)) })
            return
        }
        categories.forEach { (category, items) ->
            content.addView(text(category, 18f, green, true).apply {
                setPadding(dp(4), dp(12), dp(4), dp(8))
            })
            items.forEach { item ->
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(16), dp(14), dp(16), dp(14))
                    background = rounded(Color.WHITE, 16)
                    elevation = dp(2).toFloat()
                }
                card.addView(text(item.title, 16f, Color.rgb(35, 45, 38), true))
                card.addView(text(item.note, 12f, Color.GRAY).apply { setPadding(0, dp(4), 0, dp(8)) })
                card.addView(text(item.url, 11f, green))
                card.setOnClickListener { openService(item) }
                val params = LinearLayout.LayoutParams(-1, -2)
                params.bottomMargin = dp(10)
                content.addView(card, params)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun openService(item: ServiceLink) {
        currentTitle = item.title
        root = base()
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setBackgroundColor(green)
        }
        val back = Button(this).apply {
            text = "←"
            textSize = 20f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { showHome() }
        }
        bar.addView(back)
        bar.addView(text(item.title, 17f, Color.WHITE, true).apply {
            setPadding(dp(8), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        val home = Button(this).apply {
            text = "হোম"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { showHome() }
        }
        bar.addView(home)
        root.addView(bar)

        val wv = WebView(this)
        webView = wv
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.loadsImagesAutomatically = true
        wv.webChromeClient = WebChromeClient()
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean = false
        }
        root.addView(wv, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        wv.loadUrl(item.url)
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        val wv = webView
        if (wv != null && wv.canGoBack()) {
            wv.goBack()
        } else {
            showHome()
        }
    }
}
