# ভূমি সেবা বাংলাদেশ — Android প্রজেক্ট

এই প্রজেক্টে আপনার দেওয়া ৭টি ওয়েবসাইট বিভাগ অনুযায়ী সাজানো আছে। অ্যাপটি সার্চসহ একটি লিংক-হাব; প্রতিটি সাইট অ্যাপের ভেতরের WebView-তে খোলে।

## Android Studio দিয়ে APK তৈরি

1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. ZIP ফাইলটি Extract করুন।
3. Android Studio → **Open** → `BhumiShebaBangladesh` ফোল্ডার নির্বাচন করুন।
4. Gradle Sync শেষ হতে দিন। প্রয়োজনে Android SDK Platform 35 ইনস্টল করুন।
5. **Build → Build Bundle(s) / APK(s) → Build APK(s)** নির্বাচন করুন।
6. APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ তৈরি হবে।

## অন্তর্ভুক্ত সাইট

- https://www.amarvumi.com/
- https://eporcha.top/services/survey-khatiyan
- https://www.eporcha.tech/
- https://e-porcha.com/mouza-map
- https://www.ndsdigitalsurvey.com/mouza-map/
- https://nagoriksebahub.com/dashboard
- https://app.bhumisheba.com/

## গুরুত্বপূর্ণ

- এটি একটি প্রাথমিক সংস্করণ; কোনো ওয়েবসাইটের মালিকানা বা সরকারি অনুমোদন দাবি করে না।
- কিছু ওয়েবসাইট WebView-তে কাজ নাও করতে পারে বা নিজস্ব অ্যাপ/ব্রাউজার খুলতে পারে।
- Google Play-তে প্রকাশের আগে নিজস্ব অ্যাপ আইকন, privacy policy, target SDK এবং Play Console-এর নীতিমালা যাচাই করতে হবে।
- Debug APK ব্যক্তিগত পরীক্ষার জন্য; Play Store-এর জন্য signed release build তৈরি করতে হবে।


## মোবাইল থেকে ক্লাউডে APK Build (GitHub Actions)

প্রজেক্টে `.github/workflows/build-apk.yml` যুক্ত আছে। GitHub-এ প্রজেক্টের ফাইলগুলো আপলোড করার পর:
1. GitHub-এ repository খুলুন।
2. **Actions** ট্যাব খুলুন।
3. **Build Android APK** workflow নির্বাচন করুন।
4. **Run workflow** চাপুন।
5. Build সফল হলে workflow run-এর নিচে **Artifacts** থেকে `Bhumi-Sheba-Bangladesh-APK` ডাউনলোড করুন।
6. ZIP extract করে `app-debug.apk` ইনস্টল করুন।

এই workflow GitHub-hosted runner-এ Java, Android SDK ও Gradle দিয়ে APK তৈরি করে। GitHub Actions-এর artifact download করতে GitHub-এ sign in থাকতে হবে।
